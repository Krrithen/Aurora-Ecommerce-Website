package com.example.Cart.controller;

import com.example.Cart.dto.ProductsDTO;
import com.example.Cart.entites.Cart;
import com.example.Cart.feignClient.FeignCartService;
import com.example.Cart.services.CartService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
@Slf4j
@JsonIgnoreProperties
public class CartController {

    @Autowired
    CartService cartService;

    @Autowired
    FeignCartService feignCartService;

    @PostMapping("/AddCartDetails")
    public ResponseEntity<Cart> addCartDetails(@RequestBody Cart cart){
        ResponseEntity<Object> response =feignCartService.getProductsByProductId(cart.getProductId());
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ProductsDTO productsDTO = mapper.convertValue(response.getBody(), ProductsDTO.class);
        cartService.addCartDetails(cart,productsDTO);
        return new ResponseEntity<>(cart,HttpStatus.OK);
    }

    @DeleteMapping("/DeleteByCartId/{cartId}")
    public ResponseEntity<String> deleteByCartId(@PathVariable("cartId") String cartId) {
        cartService.deleteCartById(cartId);
        return new ResponseEntity<>("Cart Id Deleted", HttpStatus.OK);
    }

    @DeleteMapping("/DeleteAllCartItems/")
    public ResponseEntity<String> deleteAllCartItems() {
        cartService.deleteAllItems();
        return new ResponseEntity<>("Cart is Empty", HttpStatus.OK);
    }

    @GetMapping("/GetAllDetails/{id}")
    public ResponseEntity<List<Cart>> getAllDetails(){
        List<Cart> cartList=cartService.getAllCartDetails();
        return new ResponseEntity<List<Cart>>(cartList,HttpStatus.OK);
    }

    @GetMapping("/GetAllCartProducts/{userId}")
    public ResponseEntity<List<ProductsDTO>> getAllCartProducts(@PathVariable("userId") String userId){
         List<ProductsDTO> cartProducts = cartService.getProductsByUserId(userId);
         System.out.println(cartProducts);
        return new ResponseEntity<>(cartProducts,HttpStatus.OK);
    }

    @DeleteMapping("/DeleteByCartId/{userId}/{productId}")
    public ResponseEntity<String> deleteByUserProduct(@PathVariable("userId") String userId, @PathVariable("productId") String productId) {
        cartService.deleteCartItem(userId,productId);
        return new ResponseEntity<>("Cart Id Deleted", HttpStatus.OK);
    }

}
