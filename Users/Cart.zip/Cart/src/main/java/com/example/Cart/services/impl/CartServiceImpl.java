package com.example.Cart.services.impl;

import com.example.Cart.dto.ProductsDTO;
import com.example.Cart.entites.Cart;
import com.example.Cart.repository.CartRepository;
import com.example.Cart.services.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    CartRepository cartRepository;

    @Override
    public Cart addCartDetails(Cart cart,ProductsDTO productsDTO) {
        Optional<Cart> temp = cartRepository.findById(cart.getUserId());
        System.out.println(temp);
        if(temp.isPresent()){
            Cart tempCart = temp.get();
            System.out.println(tempCart);
            List<ProductsDTO> productList = tempCart.getProductsDTOList();
            if(productList == null) {
                productList = new ArrayList<>();
            }
            System.out.println(productList);
            System.out.println(productsDTO);
            productList.add(productsDTO);
            cart.setProductsDTOList(productList);
        }else{
            System.out.println("Failed List");
        }
        System.out.println(cart);
        return cartRepository.save(cart);
    }


    @Override
    public List<Cart> getAllCartDetails() {
        return cartRepository.findAll();
    }

    public void deleteCartById(String cartId) {
        cartRepository.deleteById(cartId);
    }

    @Override
    public void deleteAllItems() {
        cartRepository.deleteAll();
    }

    @Override
    public List<ProductsDTO> getProductsByUserId(String userId) {
        Cart userCart=cartRepository.findByUserId(userId).get(0);
        System.out.println(userCart);
        return userCart.getProductsDTOList();
    }

    @Override
    public boolean deleteCartItem(String userId, String productId) {
        Cart userCart=cartRepository.findByUserId(userId).get(0);
        List<ProductsDTO> productList= userCart.getProductsDTOList();
        System.out.println("List");
        System.out.println(productList);
        System.out.println(userId);
        System.out.println(productId);
        for(int i=0;i<productList.size();i++){
            if(productList.get(i).getProductId().equals(productId)){
                productList.remove(i);
            }
            else{
                System.out.println("Dint Match");
            }
        }
        userCart.setProductsDTOList(productList);
        cartRepository.save(userCart);
        return true;
    }


}
